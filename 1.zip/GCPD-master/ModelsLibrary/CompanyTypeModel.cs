﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelsLibrary
{

    public class CompanyTypeModel
    {
        public int ID { get; set; }

        public string Company { get; set; }

    }
}
