﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelsLibrary
{

    public class MyModel
    {
        public string NewName { get; set; }
    }
}
